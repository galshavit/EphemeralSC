This file contains the code needed to generate the data in the manuscript, and generate the plots from it.

Most of the code is categorized by Figure number.

The other three folders are categorized by the calculation class, spanning the data in: 
Figure 3
Figure 4
Supplementary Figures S2, S3, S5, S6